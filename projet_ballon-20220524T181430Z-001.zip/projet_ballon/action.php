<?php
/**
 * Exemple simple qui étend la classe SQLite3 et change les paramètres
 * __construct, puis, utilise la méthode de connexion pour initialiser la
 * base de données.
 */
class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('/home/pi/Desktop/rpi-rgb-led-matrix/bindings/python/samples/rasp_proj.db');
    }
}

$db = new MyDB();

if(isset($_POST['input'])){
    $db->exec("UPDATE matrix SET value='0' WHERE id='0'");
    $db->exec("UPDATE phrase_matrix SET valuetxt='".$_POST['input']."' WHERE id=0");

}
else{
    $sql = "UPDATE matrix SET value='".$_POST['parametre']."' WHERE id=0";
    $db->exec($sql);
}
$db->close();


// changer les valeurs par la base de données sur la raspberry 
?>