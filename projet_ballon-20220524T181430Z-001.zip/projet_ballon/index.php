<?php 

echo '


<html> 
    <head>
        <link rel="stylesheet" href="bootstrap.css">
        <script type="text/javascript" src="jquery.js"></script>
        <script type="text/javascript" src="ajax.js"></script>
    </head>
    <section>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand isDisabled" >Ballon dirigeable</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          
            <div class="collapse navbar-collapse" id="navbarColor02">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                    <a class="nav-link" href="index.php">Accueil
                        <span class="sr-only">(current)</span>
                    </a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="perso.php">Personnalisation message</a>
                    </li>
                </ul>  
            </div>
          </nav>
    </section>
    <div class="container">
        <body>
            <section>
                <div class="jumbotron">
                        <h3 class="text-center display-5 font-weight-bold">Choisir le mode</h3>
                        <br>
                        <table class="table table-hover text-center">
                            <tbody>
                                <tr class="table-dark">
                                    <button type="button" class="btn btn-warning" id="bouton_1" onclick="bouton_1()">Texte aléatoire</button>
                                </tr>
                            </tbody>
                        </table>
                    </div>
            </section> 
        </body>
    </div>
</html> ';

?>