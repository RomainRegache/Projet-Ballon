#!/usr/bin/env python
# PIL Image module (create or load images) is wordt hier uitgelegd:
# http://effbot.org/imagingbook/image.htm
# PIL ImageDraw module (draw shapes to images) wordt hier uitgelegd:
# http://effbot.org/imagingbook/imagedraw.htm
#code gemaakt door Dijkx kijk op www.dijkx.com voor uitleg

#importeren benodigde libraries
from samplebase import SampleBase
from PIL import Image
from PIL import ImageDraw
import time
from rgbmatrix import RGBMatrix, RGBMatrixOptions
from PIL import ImageFont
import random
import os
import sqlite3


# configuration de la Matrice 
options = RGBMatrixOptions()
options.rows = 64 # nombre de ligne : 64
options.cols = 64 # nombre de colonne : 64
options.chain_length = 1
options.parallel = 1
#options.hardware_mapping = 'regular'  #mappage regular (je sais pas ce que c'est faudra que je regarde)

matrix = RGBMatrix(options = options) # creation de la matrice avec ses options 

kleur1= random.randrange(0,255)     #creation de la premiere composante d'une couleur aleatoire
kleur2= random.randrange(0,255)     #creation de la deuxieme composante d'une couleur aleatoire
kleur3= random.randrange(0,255)     #creation de la troisieme composante d'une couleur aleatoire

#--------------------------Recuperation du text---------------------------------------------------

conn = sqlite3.connect('/var/www/html/matrix/rasp_proj.db')
cursor = conn.cursor()

rows = cursor.execute("SELECT * FROM matrix WHERE id=0").fetchone()

if int(rows[1]) == 0 : 
    print("value est égale à 0") #faire les traitements 
    row = cursor.execute("SELECT valeurtxt FROM phrase_matrice WHERE id="+rows[2]).fetchone()
    textrandom = row[0]
    conn.close()
elif int(rows[1]) == 1 :
    print("value est égale à 1") #faire les traitements 
    row = cursor.execute("SELECT valeurtxt FROM phrase_matrice WHERE id="+random.randint(0,7)).fetchone()
    textrandom = row[0]
    conn.close()



# text random -> on va pouvoir convertir l'heure en fichier mmp avec le principe de creation d'image

willekeur= "Thomas est gentil" #random.choice(       #choisie un text random dans la liste 
willekeur1=textrandom     #choisie un deuxieme texte random dans la liste 

#creation d'une image et affichage sur la matrice
#text = ((willekeur , ((kleur3), (kleur1), (kleur2))), ("et ", ((kleur1), (kleur2), (kleur3))), (willekeur1, ((kleur2), (kleur3), (kleur1))))

text = ((willekeur , ((kleur3), (kleur1), (kleur2))), (" et ", ((kleur1), (kleur2), (kleur3))), (willekeur1, ((kleur2), (kleur3), (kleur1))))


font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 22)  #font en fontsize 
#regarder sur la raspberry si la font en question existe 
    
all_text = ""
    
for text_color_pair in text:
    t = text_color_pair[0]
    all_text = all_text + t
 
print(all_text,"test")#print op de prompt alle tekst die naar de matrix gaat.
width, ignore = font.getsize(all_text)#bepaal de breedte van het plaatje
print(width, "test1")#print de breedte van het plaatje op de prompt

im = Image.new("RGB", (width + 30, 32), "black")        #32 is hoogte van plaatje in pixels
draw = ImageDraw.Draw(im)
x = 0;
    
for text_color_pair in text:
    t = text_color_pair[0]
    c = text_color_pair[1]
    print("t=" + t + " " + str(c) + " " + str(x),"test2")
    draw.text((x, 0), t, c, font=font)
    x = x + font.getsize(t)[0]
 
#im.save("imagetest/test.ppm")           #bewaar het bestand in ppm formaat
#test de ne pas sauvegarder l'image et de la mettre tel quel
#plaatjes laden 
#im0 = Image.open("collin.ppm") 
#im1 = Image.open("dijkx.ppm")
#im2 = Image.open("Surfing.ppm")
#im3 = Image.open("imagetest/test.ppm")
#im4 = Image.open("c.ppm")  #17
#im5 = Image.open("o.ppm")  #12
#im6 = Image.open("l.ppm")  #6
#im7 = Image.open("l2.ppm") #5
#im8 = Image.open("i.ppm")  #7
#im9 = Image.open("n.ppm")  #12
#im10 = Image.open("kers.ppm")  #22
#im11 = Image.open("citroen.ppm")   #20
#im12 = Image.open("meloen.ppm")    #19
#im13 = Image.open("negative.ppm")
#im14 = Image.open("noprice.ppm")
width, ignore = font.getsize(all_text)      #bepaal de breedte van het plaatje

"""
# de plaatjes laten scrollen

#slotmachine

#fruit1= random.randrange( im10, im11, im12 )   #bepaal een willekeurige kleur tussen 0 en 255
#fruit2= random.randrange( im10, im11, im12 )
#fruit3= random.randrange( im10, im11, im12 )


#eerste ring
for n in range(-32, 0):  # kers van boven buitenbeeld naar midden
    matrix.SetImage(im10, 0, n)
    time.sleep(0.001)
#time.sleep(0.1)


for n in range(0, 32):  # kers midden naar beneden buitenbeeld
    matrix.SetImage(im11, 0, n)
    time.sleep(0.001)
#time.sleep(0.1)

for n in range(-32, 0):  # cirtoen van boven buitenbeeld naar midden
    matrix.SetImage(im12, 0, n)
    time.sleep(0.001)
#time.sleep(1)

for n in range(0, 32):  # citroen van midden naar beneden buitenbeeld
    matrix.SetImage(im11, 0, n)
    time.sleep(0.001)
#time.sleep(5)

for n in range(-32, 0):  # meloen van boven buitenbeeld naar midden
    matrix.SetImage(im10, 0, n)
    time.sleep(0.001)
#time.sleep(1)
#einde eerste ring


#tweede ring
for n in range(-32, 0):  # kers van boven buitenbeeld naar midden
    matrix.SetImage(im11, 22, n)
    time.sleep(0.001)
#time.sleep(0.1)


for n in range(0, 32):  # kers midden naar beneden buitenbeeld
    matrix.SetImage(im12, 22, n)
    time.sleep(0.001)
#time.sleep(0.1)

for n in range(-32, 0):  # cirtoen van boven buitenbeeld naar midden
    matrix.SetImage(im12, 22, n)
    time.sleep(0.001)
#time.sleep(1)

for n in range(0, 32):  # citroen van midden naar beneden buitenbeeld
    matrix.SetImage(im12, 22, n)
    time.sleep(0.001)
#time.sleep(5)

for n in range(-32, 0):  # meloen van boven buitenbeeld naar midden
    matrix.SetImage(im11, 22, n)
    time.sleep(0.001)
#time.sleep(1)
#einde tweede ring

#begin derde ring
for n in range(-32, 0):  # kers van boven buitenbeeld naar midden
    matrix.SetImage(im10, 39, n)
    time.sleep(0.001)
#time.sleep(0.1)


for n in range(0, 32):  # kers midden naar beneden buitenbeeld
    matrix.SetImage(im11, 39, n)
    time.sleep(0.001)
#time.sleep(0.1)

for n in range(-32, 0):  # cirtoen van boven buitenbeeld naar midden
    matrix.SetImage(im12, 39, n)
    time.sleep(0.001)
#time.sleep(1)

for n in range(0, 32):  # citroen van midden naar beneden buitenbeeld
    matrix.SetImage(im11, 39, n)
    time.sleep(0.001)
#time.sleep(5)

for n in range(-32, 0):  # meloen van boven buitenbeeld naar midden
    matrix.SetImage(im12, 39, n)
    time.sleep(0.001)
#time.sleep(1)


#einde derde ring

time.sleep(3)

matrix.Clear()

#einde test

#smiley negative
for n in range(-32, 0):  # negative van beneden buiten beeld naar midden
    matrix.SetImage(im13, 0, -n)
    time.sleep(0.01)
time.sleep(3)
matrix.Clear()

#smiley negative

matrix.Clear()
#noprice

for n in range(-32, 0):  # noprice van links buiten beeld naar rechts midden 
    matrix.SetImage(im14, n, 0)
    time.sleep(0.001)
matrix.SetImage(im14, 0, 0)
time.sleep(0.5)
matrix.Clear()
time.sleep(0.5)
matrix.SetImage(im14, 0, 0)
time.sleep(0.5)
matrix.Clear()
time.sleep(0.5)
matrix.SetImage(im14, 0, 0)
time.sleep(0.5)
matrix.Clear()
time.sleep(0.5)
matrix.SetImage(im14, 0, 0)
time.sleep(0.5)
matrix.Clear()
time.sleep(0.5)
matrix.SetImage(im14, 0, 0)


time.sleep(2)
matrix.Clear()

#noprice
"""
for n in range(-32, 0):  # Plaatje 1 van boven naar beneden
    matrix.SetImage(im, 7, n)
    time.sleep(0.01)


matrix.SetImage(im, 7, 3)  #stuiter code
time.sleep(0.08)   
matrix.SetImage(im, 6, 0)
time.sleep(0.07)
matrix.SetImage(im, 5, 2)
time.sleep(0.06)
matrix.SetImage(im, 4, 0)
time.sleep(0.05)
matrix.SetImage(im, 3, 1)
time.sleep(0.04)   
matrix.SetImage(im, 2, 0)
time.sleep(0.03)
matrix.SetImage(im, 1, 1)
time.sleep(0.02)
matrix.SetImage(im, 0, 0)

time.sleep(0.001)

for n in range(0, im.size[0]):  # im3 van midden scherm naar rechts buiten beeld afhankelijk van de lengte van het plaatje
    matrix.SetImage(im, -n, 0) # - voor de n is van rechts naar links
    time.sleep(0.02)        #scroll snelheid
matrix.Clear()

"""
for n in range(-32, 0):  # im1 dijkx van links buiten beeld naar rechts midden 
    matrix.SetImage(im1, n, 0)
    time.sleep(0.001)
time.sleep(3)


for n in range(0, 30):  # im1 dijkx van midden naar onder buiten beeld
    matrix.SetImage(im1, 0, n)
    time.sleep(0.01)

for n in range(-32, 0):  # im1 dijkx van boven buitenbeeld naar midden
    matrix.SetImage(im1, 0, n)
    time.sleep(0.01)




for n in range(0, 30):  # im1 dijkx van midden naar onder buiten beeld
    matrix.SetImage(im1, 0, n)
    time.sleep(0.01)

for n in range(-32, 0):  # im1 dijkx van boven buitenbeeld naar midden
    matrix.SetImage(im1, 0, n)
    time.sleep(0.01)

matrix.SetImage(im1, 0, 3)  #stuiter code
time.sleep(0.08)   
matrix.SetImage(im1, 0, 0)
time.sleep(0.07)
matrix.SetImage(im1, 0, 2)
time.sleep(0.06)
matrix.SetImage(im1, 0, 0)
time.sleep(0.05)
matrix.SetImage(im1, 0, 1)
time.sleep(0.04)   
matrix.SetImage(im1, 0, 0)
time.sleep(0.03)
matrix.SetImage(im1, 0, 1)
time.sleep(0.02)
matrix.SetImage(im1, 0, 0)


time.sleep(1)
for n in range(0, 64):  # plaatje 1 van midden naar rechts buiten beeld
    matrix.SetImage(im1, n, 0)
    time.sleep(0.02)

matrix.Clear()

#surfing
for n in range(-32, 0):  # plaatje 2 Surfing van boven buitenbeeld naar midden
    matrix.SetImage(im2, 0, n)
    time.sleep(0.01)

matrix.SetImage(im2, 0, 3)  #stuiter code
time.sleep(0.08)   
matrix.SetImage(im2, 0, 0)
time.sleep(0.07)
matrix.SetImage(im2, 0, 2)
time.sleep(0.06)
matrix.SetImage(im2, 0, 0)
time.sleep(0.05)
matrix.SetImage(im2, 0, 1)
time.sleep(0.04)   
matrix.SetImage(im2, 0, 0)
time.sleep(0.03)
matrix.SetImage(im2, 0, 1)
time.sleep(0.02)
matrix.SetImage(im2, 0, 0)

time.sleep(1)

for n in range(0, im.size[0]+15):  # plaatje 2 surfing van midden naar rechts buiten beeld afhankelijk van lengte im.size[0]
    matrix.SetImage(im2, -n, 0)
    time.sleep(0.01)

matrix.Clear()
#surfing

#collin
for n in range(-32, 0):  # letter c van boven buitenbeeld naar midden
    matrix.SetImage(im4, 0, n)
    time.sleep(0.01)
time.sleep(0.1)

for n in range(-32, 0):  # letter o van boven buitenbeeld naar midden
    matrix.SetImage(im5, 17, n)
    time.sleep(0.01)
time.sleep(0.1)

for n in range(-32, 0):  # letter l van boven buitenbeeld naar midden
    matrix.SetImage(im6, 29, n)
    time.sleep(0.01)
time.sleep(0.1)


for n in range(-32, 0):  # letter l2 van boven buitenbeeld naar midden
    matrix.SetImage(im7, 35, n)
    time.sleep(0.01)
time.sleep(0.1)

for n in range(-32, 0):  # letter i van boven buitenbeeld naar midden
    matrix.SetImage(im8, 40, n)
    time.sleep(0.01)
time.sleep(0.1)

for n in range(-32, 0):  # letter n van boven buitenbeeld naar midden
    matrix.SetImage(im9, 47, n)
    time.sleep(0.01)
time.sleep(1)


for n in range(0,32):  # letter c van midden  naar onder buitenbeeld
    matrix.SetImage(im4, 0, n)
    time.sleep(0.001)
time.sleep(0.1)

for n in range(0,32):  # letter o van midden  naar onder buitenbeeld
    matrix.SetImage(im5, 17, n)
    time.sleep(0.001)
time.sleep(0.1)

for n in range(0,32):  # letter l van midden  naar onder buitenbeeld
    matrix.SetImage(im6, 29, n)
    time.sleep(0.001)
time.sleep(0.1)


for n in range(0,32):  # letter l2 van midden  naar onder buitenbeeld
    matrix.SetImage(im7, 35, n)
    time.sleep(0.001)
time.sleep(0.1)

for n in range(0,32):  # letter i van midden  naar onder buitenbeeld
    matrix.SetImage(im8, 40, n)
    time.sleep(0.001)
time.sleep(0.1)

for n in range(0,32):  # letter n van midden  naar onder buitenbeeld

    matrix.SetImage(im9, 47, n)
    time.sleep(0.001)
#collin
time.sleep(5)
matrix.Clear()


##im.size[1]  im.size[0] hier bepaal je de lengte van het plaatje mee lengte en hoogte

"""