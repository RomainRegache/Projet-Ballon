

function bouton_1() {
    console.log("traitement bouton 1");

    $.ajax({
      type: "POST",
      url: "/var/www/html/matrix/action.php",
      type:"plain/text",
      data: { parameter: "1" }
    }).done(function() {
      alert( "la requête est en cours de traitement par la raspberry");
    });
}

function bouton_2() {
    $.ajax({
      type: "POST",
      url: "action.php",
      data: { parameter: "2" }
    }).done(function() {
      alert( "la requête est en cours de traitement par la raspberry");
    });
}
